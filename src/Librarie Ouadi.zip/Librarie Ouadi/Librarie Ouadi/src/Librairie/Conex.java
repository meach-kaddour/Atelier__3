package Librairie;

import java.sql.*;
/**
 *
 * @author VANY
 */
class Conex {
    // variable static agar dpt diakses oleh class lain tanpa object
    public static Connection conn = null;
    public static Statement st = null;
    public static String NomDb, User, Password, Url;
    //variable judul aplikasi
    public String NomApplication = "Librairie Ouadi";  
            
    //constructor yg memberikan fungsi utama dan pertama dipanggil
    public Conex() throws Exception {
        //mengisi variable string dengan value tool2 database
        NomDb = "mylibrarie";
        User = "root";
        Password = "root";
        String jdbcDriver = "com.mysql.jdbc.Driver";
        Url = "jdbc:mysql://localhost:3306/" + NomDb;
        //hanya pesan di console agar terlihat sukses atau tidaknya
        System.out.println("Essayer de construire une connexion à '" + Url + "' avec user '" + User + "' et password '" + Password + "' ...");
        //mencoba menghubungkan driver aplikasi jdbc ke db
        try {
            Class.forName(jdbcDriver);
            conn = DriverManager.getConnection(Url, User, Password);
            st =  conn.createStatement();
            System.out.println("succès Connexion");
        } catch (Exception e) {
            System.out.println("Échec de la connexion");
        }

    }
}

